export const routes = {
  home: "/",
  searching: "/searching",
  tickets: "/tickets",
};
