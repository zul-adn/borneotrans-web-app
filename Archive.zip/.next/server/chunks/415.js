"use strict";
exports.id = 415;
exports.ids = [415];
exports.modules = {

/***/ 5584:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const url = "https://borneotrans-api.amazingborneo.id";
/**
 * Request Wrapper with default success/error actions
 */ const request = (options)=>{
    /**
   * Create an Axios Client with defaults
   */ const requestHeaders = options.customHeaders || {
        "Content-type": "application/json"
    };
    const additionalHeaders = options.headers || {};
    const client = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
        baseURL: options.MAIN_URL || url,
        headers: {
            ...requestHeaders,
            ...additionalHeaders,
            "Accept-Encoding": "application/json"
        }
    });
    // eslint-disable-next-line arrow-body-style
    const onSuccess = (response)=>{
        // console.debug('Request Successful!', response);
        return response.data;
    };
    const onError = (error)=>{
        console.log("Request Failed:", url);
        if (error.response) {
            // Request was made but server responded with something
            // other than 2xx
            // console.log('Status:', error.response.status);
            // console.log('Data:', error.response.data);
            // console.log('Headers:', error.response.headers);
            if (error.response.status === 401) {
            //   setTimeout(() => {
            //     Actions.reset('login');
            //     store.dispatch(clearSession());
            //   }, 200);
            }
        }
        return Promise.reject(error.response || error.message);
    };
    return client(options).then(onSuccess).catch(onError);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (request);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3415:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ey": () => (/* binding */ getBanners),
/* harmony export */   "P_": () => (/* binding */ getConfiguration),
/* harmony export */   "Rn": () => (/* binding */ getCars),
/* harmony export */   "SP": () => (/* binding */ getTickets),
/* harmony export */   "Vr": () => (/* binding */ getArticleById),
/* harmony export */   "XS": () => (/* binding */ getTrips),
/* harmony export */   "Zz": () => (/* binding */ getArticles),
/* harmony export */   "hA": () => (/* binding */ getAdmin),
/* harmony export */   "kW": () => (/* binding */ getPartner),
/* harmony export */   "pw": () => (/* binding */ getDestinations)
/* harmony export */ });
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5584);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_0__]);
_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getBanners = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/banner",
        method: "GET"
    });
const searchTicket = ()=>{};
const getDestinations = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/cities-destination?$limit=100",
        method: "GET"
    });
const getCars = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/vehicle-details?$limit=100",
        method: "GET"
    });
const getTickets = (params)=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: `/ticket?$limit=100&main_from=${params.main_from}&main_to=${params.main_to}&date=${params.date}`,
        method: "GET"
    });
const getTrips = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/routes-trip?$limit=100",
        method: "GET"
    });
const getPartner = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/partner",
        method: "GET"
    });
const getAdmin = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/users?$limit=50",
        method: "GET"
    });
const getArticles = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/article?$limit=50",
        method: "GET"
    });
const getArticleById = (id)=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: `/article?id=${id}`,
        method: "GET"
    });
const getConfiguration = ()=>(0,_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        url: "/configuration",
        method: "GET"
    });


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;