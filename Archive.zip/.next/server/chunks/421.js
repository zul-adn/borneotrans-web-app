"use strict";
exports.id = 421;
exports.ids = [421];
exports.modules = {

/***/ 8769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "zx": () => (/* reexport */ Button_Index),
  "Zb": () => (/* reexport */ Card_Index),
  "vS": () => (/* reexport */ CardArticle_Index),
  "lr": () => (/* reexport */ Index),
  "$_": () => (/* reexport */ index),
  "u_": () => (/* reexport */ Modal_index),
  "wp": () => (/* reexport */ Navbar),
  "Rj": () => (/* reexport */ SearchBox_Index),
  "NZ": () => (/* reexport */ SectionTitle_Index),
  "oB": () => (/* reexport */ TicketCard_Index)
});

// UNUSED EXPORTS: ImageViewer

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-device-detect"
var external_react_device_detect_ = __webpack_require__(3599);
;// CONCATENATED MODULE: ./src/components/navbar/index.js




const assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function Navbar({ content  }) {
    const [openMobileMenu, setOpenMobileMenu] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                id: "nav",
                className: "sticky top-0 z-10 bg-white backdrop-filter backdrop-blur-lg bg-opacity-30 ",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-w-5xl mx-auto px-4",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between h-16",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: `${assets_url}/config/${content?.configuration.data[0].logo}`,
                                    alt: "car",
                                    className: "w-36 ",
                                    loading: "lazy"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "hidden space-x-8 text-gray-900 md:flex lg:flex ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/article",
                                        children: "Article"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/rentcar",
                                        children: "Rent"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/aboutus",
                                        children: "About us"
                                    })
                                ]
                            }),
                            external_react_device_detect_.isMobile ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                viewBox: "0 0 100 80",
                                width: "40",
                                height: "25",
                                onClick: ()=>setOpenMobileMenu(!openMobileMenu),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                        width: "80",
                                        height: "15",
                                        rx: "10"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                        y: "30",
                                        width: "100",
                                        height: "15",
                                        rx: "10"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                        y: "60",
                                        width: "80",
                                        height: "15",
                                        rx: "10"
                                    })
                                ]
                            }) : null
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${openMobileMenu ? "flex" : "hidden"} h-full bg-white fixed flex-col text-right z-30 w-1/2 right-0 top-0 shadow-sm`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-8 pt-5 pr-5 flex justify-end items-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "20",
                            height: "20",
                            viewBox: "0 0 24 24",
                            onClick: ()=>setOpenMobileMenu(false),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M24 20.188l-8.315-8.209 8.2-8.282-3.697-3.697-8.212 8.318-8.31-8.203-3.666 3.666 8.321 8.24-8.206 8.313 3.666 3.666 8.237-8.318 8.285 8.203z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        className: "text-3xl mb-2 border-b-2 p-2",
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/article",
                        className: "text-3xl mb-2 border-b-2 p-2",
                        children: "Article"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/rentcar",
                        className: "text-3xl mb-2 border-b-2 p-2",
                        children: "Rent"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/aboutus",
                        className: "text-3xl mb-2 border-b-2 p-2",
                        children: "About us"
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
// EXTERNAL MODULE: external "react-responsive-carousel"
var external_react_responsive_carousel_ = __webpack_require__(4508);
// EXTERNAL MODULE: ./node_modules/next/legacy/image.js
var legacy_image = __webpack_require__(9755);
;// CONCATENATED MODULE: ./src/components/Carousel/index.js
/* eslint-disable @next/next/no-img-element */ 




const backendUrl = "https://borneotrans-api.amazingborneo.id/uploads";
function Index(props) {
    const { images  } = props;
    const settings = {
        dots: true,
        autoplay: true,
        infinite: true,
        slidesToScroll: 1
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `w-full top-0 absolute h-3/5 bg-white -z-10`,
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_responsive_carousel_.Carousel, {
            autoPlay: true,
            infiniteLoop: true,
            transitionTime: 2000,
            interval: 5000,
            dynamicHeight: 200,
            showArrows: false,
            showThumbs: false,
            children: images.data.map((img, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        height: 950
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: `w-full h-3/5 mb-10 object-cover`,
                        src: `${backendUrl}/banner/${img.filename}`
                    })
                }, i))
        })
    });
}

// EXTERNAL MODULE: external "react-search-autocomplete"
var external_react_search_autocomplete_ = __webpack_require__(2827);
// EXTERNAL MODULE: external "react-datepicker"
var external_react_datepicker_ = __webpack_require__(8743);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: external "date-fns/locale/id"
var id_ = __webpack_require__(9999);
var id_default = /*#__PURE__*/__webpack_require__.n(id_);
;// CONCATENATED MODULE: ./src/components/SearchBox/index.js










(0,external_react_datepicker_.registerLocale)("id", (id_default()));
function SearchBox_Index(props) {
    const { destination  } = props;
    external_react_default().useEffect(()=>{
        console.log(destination);
        mergeCities();
    }, []);
    const [values, setValue] = external_react_default().useState({
        from: "",
        to: "",
        date: new Date()
    });
    const [cities, setCities] = external_react_default().useState([]);
    function mergeCities() {
        var uniq = {};
        var arr = [
            ...destination?.data
        ];
        var result = arr.reduce((unique, o)=>{
            if (!unique.some((obj)=>obj.name.trim() === o.name.trim())) {
                unique.push(o);
            }
            return unique;
        }, []);
        setCities(result);
    }
    const formatResult = (item)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                style: {
                    display: "block",
                    textAlign: "left"
                },
                children: item.name
            })
        });
    };
    const handleOnSelectRoute = (prop)=>(item)=>{
            setValue({
                ...values,
                [prop]: item.name
            });
        };
    const onChangeDate = (e)=>{
        const newDate = external_moment_default()(new Date(e.target.value)).format("DD/MM/YYYY");
        setValue({
            ...values,
            date: newDate
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `lg:max-w-5xl md:max-w-5xl lg:mx-auto md:mx-auto sm:mx-auto  border rounded mt-80 bg-white z-50 shadow-lg `,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center justify-start border-b px-5 py-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: `text-lg`,
                    children: "Hai kamu, mau ke mana?"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "lg:flex md:flex items-center justify-around p-5 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full p-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "block text-gray-700 text-sm font-bold mb-2",
                                children: "Berangkat dari"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_search_autocomplete_.ReactSearchAutocomplete, {
                                items: cities,
                                onSelect: handleOnSelectRoute("from"),
                                formatResult: formatResult,
                                placeholder: "Berangkat dari",
                                styling: {
                                    zIndex: 2,
                                    borderRadius: 2
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full p-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "block text-gray-700 text-sm font-bold mb-2",
                                children: "Ke Kota"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_search_autocomplete_.ReactSearchAutocomplete, {
                                items: cities,
                                onSelect: handleOnSelectRoute("to"),
                                formatResult: formatResult,
                                placeholder: "Ke Kota",
                                styling: {
                                    zIndex: 2,
                                    borderRadius: 2
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "lg:w-3/4 sm:w-full p-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "block text-gray-700 text-sm font-bold mb-2",
                                children: "Tanggal"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " appearance-none border w-full py-3 px-3 bg-white text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "date",
                                onChange: onChangeDate
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center justify-end p-5 ",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    className: `w-full py-2 rounded px-5 bg-blue-500 -mt-5 mr-1 text-center text-sm xl:text-md lg:text-md text-white`,
                    href: `tickets?main_from=${values.from}&main_to=${values.to}&date=${values.date}`,
                    children: "Cari Ticket"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/Card/index.js
/* eslint-disable @next/next/no-img-element */ 



const Card_assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function Card_Index(props) {
    const { image , name , brand , price , availability , owndriven , maintype , onClick , onImageClick  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `flex flex-col drop-shadow-md hover:drop-shadow-xl rounded-md p-2 bg-white cursor-pointer`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `w-full aspect-square`,
                        onClick: onImageClick,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: `${Card_assets_url}/vehicles/${image}`,
                            alt: "car",
                            className: "w-full h-full rounded  object-cover "
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `flex flex-col mt-3 p-2`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `text-xs font-semibold`,
                                children: brand
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `text-lg `,
                                children: name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${availability ? "text-green-800 text-sm font-semibold" : " text-gray-500 text-sm"}  `,
                                children: availability ? "Tersedia" : "Tidak Tersedia"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "justify-self-end",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-right mb-7 text-lg text-orange-600 font-semibold mr-2",
                        children: [
                            "Rp ",
                            price?.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Button_Index, {
                        onClick: onClick,
                        label: "Pesan Sekarang"
                    })
                ]
            }),
            owndriven ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute bg-green-500 right-0 mr-3 mt-2 px-5 rounded text-white text-sm py-1",
                children: [
                    " ",
                    "Lepas Kunci"
                ]
            }) : null
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/Button/index.js


function Button_Index(props) {
    const { label , onClick  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `w-full py-2 rounded px-5 bg-blue-500 -mt-5 mr-1 text-center text-sm xl:text-md lg:text-md`,
        onClick: ()=>onClick(),
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            className: `text-white`,
            children: label
        })
    });
}

;// CONCATENATED MODULE: ./src/components/SectionTitle/index.js


function SectionTitle_Index(props) {
    const { title , subtitle  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `max-w-5xl mx-auto   mt-20 bg-white `,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-4xl font-bold text-black",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "mt-2 text-gray-600 text-xl",
                children: subtitle
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/TicketCard/index.js
/* eslint-disable @next/next/no-img-element */ 





const TicketCard_assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function TicketCard_Index(props) {
    const { from , to , price , date , time , partner , trip , ticket_partner , onClick  } = props;
    const d = new Date(date);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: external_react_device_detect_.isMobile ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `flex flex-col justify-between drop-shadow-md hover:drop-shadow-xl rounded-sm bg-white cursor-pointer p-4 mt-2`,
            onClick: ()=>onClick(props),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-center text-lg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `w-28 flex justify-center items-center flex-col py-4`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: `${TicketCard_assets_url}/partners/${partner[0]?.img}`,
                                style: {
                                    width: "50%",
                                    height: "auto"
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex mt-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: `text-xs`,
                                            children: " "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-1 h-full  mx-5 bg-black my-1"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-center items-center flex-col px-1 ",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-semibold",
                                                    children: from
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm ",
                                                    children: trip[0].from
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col mt-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-semibold",
                                                    children: to
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm ",
                                                    children: trip[0].to
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row justify-between items-center mt-5 px-5 pt-2",
                    style: {
                        borderTop: "1px solid #bdc3c7"
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `flex flex-col `,
                            children: [
                                date,
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `text-xl`,
                                    children: time
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `flex flex-col items-center justify-center`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-right text-orange-600 font-semibold mr-2 text-xl ",
                                children: [
                                    "Rp",
                                    " ",
                                    trip[0].price?.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"),
                                    " "
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button_Index, {
                        label: "Pesan",
                        onClick: ()=>onClick(props)
                    })
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `flex flex-row justify-between drop-shadow-md hover:drop-shadow-xl rounded-sm p-2 bg-white cursor-pointer p-4 mt-2`,
            onClick: ()=>onClick(props),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row items-center text-lg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `w-28 flex justify-center items-center flex-col`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: `${TicketCard_assets_url}/partners/${partner[0]?.img}`,
                                style: {
                                    width: "100%",
                                    height: "auto"
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex mt-4 w-96",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: `text-xs`,
                                            children: " "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-0.5 h-full mx-5 bg-black my-1"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-center items-center flex-col px-1 ",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-semibold",
                                                    children: from
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm ",
                                                    children: trip[0].from
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col mt-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-semibold",
                                                    children: to
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-sm ",
                                                    children: trip[0].to
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `flex flex-col  justify-center items-center`,
                    children: [
                        date,
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: `text-xl font-bold`,
                            children: time
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `flex flex-col items-center justify-center `,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-right  text-orange-600 font-semibold mr-2 text-2xl",
                        children: [
                            "Rp",
                            " ",
                            trip[0].price?.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center items-center w-40 mt-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button_Index, {
                        label: "Pesan",
                        onClick: ()=>onClick(props)
                    })
                })
            ]
        })
    });
}

// EXTERNAL MODULE: external "moment/moment"
var moment_ = __webpack_require__(3332);
var moment_default = /*#__PURE__*/__webpack_require__.n(moment_);
// EXTERNAL MODULE: external "moment/locale/id"
var locale_id_ = __webpack_require__(5518);
;// CONCATENATED MODULE: ./src/components/CardArticle/index.js
/* eslint-disable @next/next/no-img-element */ 




moment_default()().locale("id");
const CardArticle_assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function CardArticle_Index(props) {
    const { id , title , article , image , createAt  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: `/detailarticle?id=${id}`,
        className: `flex flex-col  shadow-md hover:drop-shadow-md rounded-md bg-white cursor-pointer`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `w-full aspect-square`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        // src={`${assets_url}/article/${JSON.parse(image)[0]}`}
                        src: `${CardArticle_assets_url}/article/${JSON.parse(image)[0]}`,
                        alt: "article",
                        className: "w-full h-full  rounded-t-md  object-cover",
                        loading: "lazy"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `flex flex-col mt-3 p-5`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `text-xs font-semibold text-black`,
                            children: moment_default()(createAt).format("LLL")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `font-bold text-xl mb-2 line-clamp-2 text-black`,
                            children: title
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/Footer/index.js


const Footer_assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function index({ content  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "text-center bg-gray-900 text-white mt-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-5xl mx-auto px-4",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container px-6 pt-6",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid lg:grid-cols-3 md:grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-6 flex flex-col justify-start items-center pr-10 pt-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: `${Footer_assets_url}/config/${content?.configuration.data[0].logo}`,
                                        alt: "logo",
                                        className: "w-5/6 mb-4",
                                        loading: "lazy"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-center mb-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: `https://www.facebook.com/${content?.configuration.data[0].social_media ? JSON.parse(content?.configuration.data[0].social_media)[1]["values"] : "#"}`,
                                                rel: "noreferrer",
                                                target: "_blank",
                                                type: "button",
                                                className: "rounded-full border-2 border-white text-white leading-normal uppercase hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0 transition duration-150 ease-in-out w-9 h-9 m-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                    "aria-hidden": "true",
                                                    focusable: "false",
                                                    "data-prefix": "fab",
                                                    "data-icon": "facebook-f",
                                                    className: "w-2 h-full mx-auto",
                                                    role: "img",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 320 512",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        fill: "currentColor",
                                                        d: "M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: `https://goo.gl/maps/${content?.configuration.data[0].social_media ? JSON.parse(content?.configuration.data[0].social_media)[2]["values"] : "#"}`,
                                                rel: "noreferrer",
                                                type: "button",
                                                target: "_blank",
                                                className: "rounded-full border-2 justify-center items-center border-white text-white leading-normal uppercase hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0 transition duration-150 ease-in-out w-9 h-9 m-1",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "14",
                                                    height: "14",
                                                    fill: "currentColor",
                                                    className: "w-3 h-full mx-auto",
                                                    viewBox: "0 0 14 14",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: `https://www.instagram.com/${content?.configuration.data[0].social_media ? JSON.parse(content?.configuration.data[0].social_media)[0]["values"] : "#"}`,
                                                target: "_blank",
                                                rel: "noreferrer",
                                                type: "button",
                                                className: "rounded-full border-2 border-white text-white leading-normal uppercase hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0 transition duration-150 ease-in-out w-9 h-9 m-1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                    "aria-hidden": "true",
                                                    focusable: "false",
                                                    "data-prefix": "fab",
                                                    "data-icon": "instagram",
                                                    className: "w-3 h-full mx-auto",
                                                    role: "img",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 448 512",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        fill: "currentColor",
                                                        d: "M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-6 flex flex-col justify-start items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "uppercase font-bold mb-2.5",
                                        children: "Partners"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "grid grid-cols-4 gap-4 mt-4",
                                        children: content?.partners.data.slice(0, 11).map((v, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                title: v.name,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: `${Footer_assets_url}/partners/${v.img}`,
                                                    className: "rounded-full aspect-square",
                                                    style: {
                                                        width: 50
                                                    }
                                                })
                                            }, i))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-6 flex flex-col justify-start items-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "uppercase font-bold mb-2.5",
                                        children: "About us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-justify",
                                            dangerouslySetInnerHTML: {
                                                __html: content?.configuration.data[0].about_us
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center p-4",
                style: {
                    backgroundColor: " rgba(0, 0, 0, 0.2)"
                },
                children: [
                    "\xa9 2021 Copyright:",
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "text-white",
                        href: "https://tailwind-elements.com/",
                        children: "Borneotrans"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/Modal/index.js



function Modal_index(props) {
    const { show , setModalClose , title , onSubmit , width , cb  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: show ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `relative ${width ?? "w-auto"}  my-6 mx-auto max-w-3xl`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-start justify-between p-5 border-b border-solid border-slate-200 rounded-t",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "text-xl font-semibold",
                                            children: title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none",
                                            onClick: ()=>setModalClose(),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "bg-transparent text-black opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none",
                                                children: "\xd7"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `px-5 py-10`,
                                    children: props.children
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
                                            type: "button",
                                            onClick: ()=>setModalClose(),
                                            children: "Close"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Button_Index, {
                                            label: "Simpan Data",
                                            type: "primary",
                                            onClick: ()=>onSubmit()
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "opacity-25 fixed inset-0 z-40 bg-black"
                })
            ]
        }) : null
    });
}

// EXTERNAL MODULE: external "react-simple-image-viewer"
var external_react_simple_image_viewer_ = __webpack_require__(5745);
;// CONCATENATED MODULE: ./src/components/ImageViewer/index.js



const ImageViewer_assets_url = (/* unused pure expression or super */ null && ("https://borneotrans-api.amazingborneo.id/uploads"));
function ImageViewer_Index(props) {
    const { show , images , url , setShow  } = props;
    const [currentImage, setCurrentImage] = useState(0);
    const [isViewerOpen, setIsViewerOpen] = useState(false);
    const [imageToShow, setImageToShow] = useState([]);
    const [imageReady, setImageReady] = useState(false);
    useEffect(()=>{
        const cpImageToShow = [
            ...imageToShow
        ];
        images?.forEach((img)=>{
            cpImageToShow.push(`${ImageViewer_assets_url}/vehicles/${img}`);
        });
        setImageToShow(cpImageToShow);
        setImageReady(true);
    }, [
        images
    ]);
    const openImageViewer = useCallback((index)=>{
        setCurrentImage(index);
        setIsViewerOpen(true);
    }, []);
    const closeImageViewer = ()=>{
        setCurrentImage(0);
        setShow(false);
    };
    return /*#__PURE__*/ _jsx("div", {
        children: show && imageReady && /*#__PURE__*/ _jsx(ImageViewer, {
            src: imageToShow,
            currentIndex: currentImage,
            onClose: closeImageViewer,
            disableScroll: false,
            backgroundStyle: {
                backgroundColor: "rgba(0,0,0,0.9)"
            },
            closeOnClickOutside: true
        })
    });
}

;// CONCATENATED MODULE: ./src/components/index.js














/***/ }),

/***/ 5421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8769);




function Layout(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: `${props?.title ?? ""} - Borneo Trans`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_3__/* .Navbar */ .wp, {
                content: props.content
            }),
            props.children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_3__/* .Footer */ .$_, {
                content: props.content
            })
        ]
    });
}


/***/ })

};
;