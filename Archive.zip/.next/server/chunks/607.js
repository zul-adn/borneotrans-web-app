"use strict";
exports.id = 607;
exports.ids = [607];
exports.modules = {

/***/ 607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Index)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8769);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment_locale_id__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5518);
/* harmony import */ var moment_locale_id__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_locale_id__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_simple_image_viewer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5745);
/* harmony import */ var react_simple_image_viewer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_simple_image_viewer__WEBPACK_IMPORTED_MODULE_5__);





moment_moment__WEBPACK_IMPORTED_MODULE_3___default()().locale("id");

const assets_url = "https://borneotrans-api.amazingborneo.id/uploads";
function Index(props) {
    const { vehicles , itemToShow , filterBy , admin  } = props;
    const [showModal, setShowModal] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [tickectProps, setTicketProps] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [images, setImages] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [showPreview, setShowPreview] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [values, setValue] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        name: "",
        phoneNumber: "",
        rentStartDate: "",
        totalDays: "",
        pickUpPlace: "",
        time: ""
    });
    const [currentImage, setCurrentImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [isViewerOpen, setIsViewerOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [imageToShow, setImageToShow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const handleChange = (prop)=>(event)=>{
            setValue({
                ...values,
                [prop]: event.target.value
            });
        };
    function booking(props) {
        setShowModal(!showModal);
        console.log(props);
        setTicketProps(props);
    }
    function sendWA() {
        const phoneNumber = admin.data[Math.floor(Math.random() * admin.data.length)];
        window.open(`https://wa.me/${phoneNumber.wa_number}?text=Informasi%20pemesanan%20%3A%0A%E2%80%A2%20Nama%20%3A%20${values.name}%0A%E2%80%A2%20Jenis%20Unit%20%3A%20${tickectProps.brand}(${tickectProps.name})%0A%E2%80%A2%20Alamat%20Jemput%20%3A%20${values.pickUpPlace}%0A%E2%80%A2%20Tanggal%20%3A%20${values.rentStartDate}%0A%E2%80%A2%20Jumlah%20Hari%20%3A%20${values.totalDays}%0A%E2%80%A2%20Whatsapp%20%3A%20${values.phoneNumber}%0A%0AKami%20akan%20segera%20konfirmasi%20jika%20Kendaraan%20tersedia.%20%0ATrimakasih.%0Aborneotrans.com`, "_blank");
    }
    const onChangeDate = (e)=>{
        const newDate = moment_moment__WEBPACK_IMPORTED_MODULE_3___default()(new Date(e.target.value)).format("DD/MM/YYYY");
        setValue({
            ...values,
            rentStartDate: newDate
        });
    };
    const showImage = (images)=>{
        let image = [];
        console.log(imageToShow);
        setImageToShow([]);
        const cpImageToShow = [
            ...imageToShow
        ];
        JSON.parse(images)?.forEach((img)=>{
            image.push(`${assets_url}/vehicles/${img}`);
        });
        setImageToShow(image);
        openImageViewer(0);
    };
    const openImageViewer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((index)=>{
        const nav = document.getElementById("nav");
        nav.style.zIndex = 0;
        setCurrentImage(index);
        setIsViewerOpen(true);
    }, []);
    const closeImageViewer = ()=>{
        const nav = document.getElementById("nav");
        nav.style.zIndex = 10;
        setCurrentImage(0);
        setIsViewerOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `max-w-5xl mx-auto mt-10`,
        children: [
            isViewerOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_simple_image_viewer__WEBPACK_IMPORTED_MODULE_5___default()), {
                src: imageToShow,
                currentIndex: currentImage,
                disableScroll: false,
                closeOnClickOutside: true,
                onClose: closeImageViewer
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `grid m-auto grid-cols-2 xl:grid-cols-4 lg:grid-cols-4 gap-2 lg:gap-2`,
                children: vehicles?.data.filter((car)=>filterBy === "Bus" ? car.maintype === "" : car.maintype === "Mini Bus")?.slice(0, itemToShow ?? vehicles.length).sort((a, b)=>a.availability && b.availability ? null : -1).map((vehicle, index)=>{
                    let images = JSON.parse(vehicle?.thumbnail);
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Card */ .Zb, {
                            name: vehicle?.name,
                            brand: vehicle?.brand,
                            availability: vehicle?.available,
                            price: vehicle?.price_per_day,
                            owndriven: vehicle?.own_driving,
                            maintype: vehicle?.maintype,
                            image: images[Math.floor(Math.random() * images.length)],
                            onClick: ()=>booking(vehicle),
                            onImageClick: ()=>showImage(vehicle?.thumbnail)
                        }, `vehicle-${index}`)
                    });
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components__WEBPACK_IMPORTED_MODULE_2__/* .Modal */ .u_, {
                show: showModal,
                setModalClose: ()=>{
                    setShowModal(!showModal);
                },
                title: `Rental Mobil`,
                width: "1/2",
                onSubmit: ()=>sendWA(),
                cb: ()=>sendWA(),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                class: "block text-gray-700 text-sm font-bold mb-2",
                                for: "username",
                                children: "Nama Pemesan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "text",
                                placeholder: "Nama Pemesan",
                                value: values.name,
                                onChange: handleChange("name"),
                                required: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                class: "block text-gray-700 text-sm font-bold my-2",
                                for: "username",
                                children: "Nomor Handphone"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "text",
                                placeholder: "Nomor Handphone",
                                value: values.phoneNumber,
                                onChange: handleChange("phoneNumber"),
                                required: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                class: "block text-gray-700 text-sm font-bold my-2",
                                for: "username",
                                children: "Lokasi Penjemputan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "text",
                                placeholder: "Lokasi Penjemputan",
                                value: values.pickUpPlace,
                                onChange: handleChange("pickUpPlace"),
                                required: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                class: "block text-gray-700 text-sm font-bold my-2",
                                for: "username",
                                children: "Tanggal Penjemputan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "date",
                                placeholder: "Jumlah Ticket",
                                value: values.totalTicket,
                                onChange: onChangeDate,
                                required: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                class: "block text-gray-700 text-sm font-bold my-2",
                                for: "username",
                                children: "Jumlah hari pemakaian"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                                type: "number",
                                placeholder: "Jumlah Hari Pemakaian",
                                value: values.totalTicket,
                                onChange: handleChange("totalDays"),
                                required: true
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col mt-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-bold",
                                children: "Detail Rental dan Kendaraan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-sm mt-2",
                                children: "Detail Kendaraan"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "font-semibold",
                                children: [
                                    tickectProps?.brand,
                                    " ( ",
                                    tickectProps?.name,
                                    " )"
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;